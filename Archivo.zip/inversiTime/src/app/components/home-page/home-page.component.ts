import { Component } from '@angular/core';
import { CalculationService } from '../../services/calculation.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { CalculationResult } from '../../models/CalculationResult';
import { UserserviceService } from '../../services/userservice.service';
import { ProductserviceService } from '../../services/productservice.service';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [FormsModule, CommonModule, HttpClientModule],
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.css'
})
export class HomePageComponent {
  producto = 1;
  enReinversion = false;
  plazo = 0;
  fechaCreacion = '';
  result: CalculationResult | null = null;

  nombreUsuario = '';
  emailUsuario = '';
  passwordUsuario = ''; 

  usuarios: any[] = [];

  editMode = false;
  usuarioIdEnEdicion: number | null = null; 

  productos: any[] = [];
  nombreProducto = '';
  dias_menor_igual_operativa_no_reinversion: number | null = null;
  dias_mayor_operativa_no_reinversion: number | null = null;
  dias_menor_igual_operativa_reinversion: number | null = null;
  dias_mayor_operativa_reinversion: number | null = null;
  hora_operativa = '';
  productoIdEnEdicion: number | null = null;

  constructor(
    private calculationService: CalculationService, 
    private userService: UserserviceService,
    private productService: ProductserviceService) {
    this.obtenerProductos();
  }

  calcularFechas() {
    const data = {
      producto: this.producto,
      enReinversion: this.enReinversion,
      plazo: this.plazo,
      fechaCreacion: this.fechaCreacion,
    };

    this.calculationService.calcularFechas(data).subscribe(
      (response) => {
        this.result = response;
      },
      (error) => {
        console.error('Error al calcular fechas:', error);
      }
    );
  }

  onModalOpen() {
    this.obtenerUsuarios();
  }

  
  obtenerUsuarios() {
    this.userService.getUsers().subscribe(
      (response) => {
        this.usuarios = response;
      },
      (error) => {
        console.error('Error al obtener usuarios:', error);
      }
    );
  }

  cargarDatosUsuario(usuario: any) {
    this.editMode = true;
    this.usuarioIdEnEdicion = usuario.id;
    this.nombreUsuario = usuario.nombre;
    this.emailUsuario = usuario.email;
    this.passwordUsuario = '';
  }

  guardarUsuario() {
    if (this.editMode && this.usuarioIdEnEdicion) {
      this.userService.updateUser(this.usuarioIdEnEdicion, this.nombreUsuario, this.emailUsuario, this.passwordUsuario ? this.passwordUsuario : undefined).subscribe(
        (response) => {
          console.log('Usuario actualizado:', response);
          this.resetFormulario();
          this.obtenerUsuarios();
        },
        (error) => {
          console.error('Error al actualizar usuario:', error);
        }
      );
    } else {
      this.userService.createUser(this.nombreUsuario, this.emailUsuario, this.passwordUsuario).subscribe(
        (response) => {
          console.log('Usuario creado:', response);
          this.resetFormulario();
          this.obtenerUsuarios();
        },
        (error) => {
          console.error('Error al crear usuario:', error);
        }
      );
    }
  }

  eliminarUsuario(id: number) {
    this.userService.deleteUser(id).subscribe(
      (response) => {
        console.log('Usuario eliminado:', response);
        this.obtenerUsuarios();
      },
      (error) => {
        console.error('Error al eliminar usuario:', error);
      }
    );
  }

  resetFormulario() {
    this.editMode = false;
    this.usuarioIdEnEdicion = null;
    this.nombreUsuario = '';
    this.emailUsuario = '';
    this.passwordUsuario = '';
  }

  obtenerProductos() {
    this.productService.getProducts().subscribe(
      (response) => {
        this.productos = response;
      },
      (error) => {
        console.error('Error al obtener productos:', error);
      }
    );
  }

  cargarDatosProducto(producto: any) {
    this.editMode = true;
    this.productoIdEnEdicion = producto.id;
    this.nombreProducto = producto.nombre;
    this.dias_menor_igual_operativa_no_reinversion = producto.dias_menor_igual_operativa_no_reinversion;
    this.dias_mayor_operativa_no_reinversion = producto.dias_mayor_operativa_no_reinversion;
    this.dias_menor_igual_operativa_reinversion = producto.dias_menor_igual_operativa_reinversion;
    this.dias_mayor_operativa_reinversion = producto.dias_mayor_operativa_reinversion;
    this.hora_operativa = producto.hora_operativa;
  }

  guardarProducto() {
    const productData = {
      nombre: this.nombreProducto,
      dias_menor_igual_operativa_no_reinversion: this.dias_menor_igual_operativa_no_reinversion,
      dias_mayor_operativa_no_reinversion: this.dias_mayor_operativa_no_reinversion,
      dias_menor_igual_operativa_reinversion: this.dias_menor_igual_operativa_reinversion,
      dias_mayor_operativa_reinversion: this.dias_mayor_operativa_reinversion,
      hora_operativa: this.hora_operativa
    };

    if (this.editMode && this.productoIdEnEdicion) {
      this.productService.updateProduct(this.productoIdEnEdicion, productData).subscribe(
        (response) => {
          console.log('Producto actualizado:', response);
          this.resetFormularioProducto();
          this.obtenerProductos();
        },
        (error) => {
          console.error('Error al actualizar producto:', error);
        }
      );
    } else {
      this.productService.createProduct(productData).subscribe(
        (response) => {
          console.log('Producto creado:', response);
          this.resetFormularioProducto();
          this.obtenerProductos();
        },
        (error) => {
          console.error('Error al crear producto:', error);
        }
      );
    }
  }

  eliminarProducto(id: number) {
    this.productService.deleteProduct(id).subscribe(
      (response) => {
        console.log('Producto eliminado:', response);
        this.obtenerProductos();
      },
      (error) => {
        console.error('Error al eliminar producto:', error);
      }
    );
  }

  resetFormularioProducto() {
    this.editMode = false;
    this.productoIdEnEdicion = null;
    this.nombreProducto = '';
    this.dias_menor_igual_operativa_no_reinversion = null;
    this.dias_mayor_operativa_no_reinversion = null;
    this.dias_menor_igual_operativa_reinversion = null;
    this.dias_mayor_operativa_reinversion = null;
    this.hora_operativa = '';
  }
}