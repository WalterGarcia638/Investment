import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
  private http = inject(HttpClient);
  private apiUrl = 'http://127.0.0.1:5000/api';

  createUser(nombre: string, email: string, password: string): Observable<any> {
    const userData = { nombre, email, password };
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.post(`${this.apiUrl}/user`, userData, { headers });
  }

  updateUser(id: number, nombre: string, email: string, password?: string): Observable<any> {
    const userData: any = { nombre, email };
    if (password) {
      userData.password = password;
    }
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    return this.http.put(`${this.apiUrl}/user/${id}`, userData, { headers });
  }

  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/user/${id}`);
  }

  getUsers(): Observable<any> {
    return this.http.get(`${this.apiUrl}/users`);
  }

  getUserById(id: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/user/${id}`);
  }
}