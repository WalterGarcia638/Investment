export interface CalculationResult {
    producto: number;
    plazo: number;
    fechaInicio: string;
    fechaFin: string;
    plazoReal: number;
  }